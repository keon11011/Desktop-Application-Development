﻿namespace GUI
{
    partial class frmChiTietQuyDinhGiamGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbSuaXoaQuyDinhGiamGia = new System.Windows.Forms.Label();
            this.btnSuaQuyDinhGiamGia = new System.Windows.Forms.Button();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.lbTrangThai = new System.Windows.Forms.Label();
            this.dateTimePickerNgayBatDau = new System.Windows.Forms.DateTimePicker();
            this.lbPhanTramGiamGiaMacDinh = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbNgayBatDau = new System.Windows.Forms.Label();
            this.dateTimePickerNgayKetThuc = new System.Windows.Forms.DateTimePicker();
            this.lbNgayKetThuc = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numUpDownPhanTramGiamGiaMacDinh = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPhanTramGiamGiaToiDa = new System.Windows.Forms.NumericUpDown();
            this.lbPhanTramGiamGiaToiDa = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numUpDownSoLuongKhoaHocDangKy = new System.Windows.Forms.NumericUpDown();
            this.lbSoLuongKhoaHocDangKy = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cboNgheNghiep = new System.Windows.Forms.ComboBox();
            this.lbTenNgheNghiep = new System.Windows.Forms.Label();
            this.txtMoTaLoaiGiamGia = new System.Windows.Forms.TextBox();
            this.lbMoTaLoaiGiamGia = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMaQuyDinhGiamGia = new System.Windows.Forms.TextBox();
            this.lbMaQuyDinhGiamGia = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSelectedXoa = new System.Windows.Forms.Button();
            this.btnSelectedSua = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnNoDate = new System.Windows.Forms.RadioButton();
            this.rbtnYesDate = new System.Windows.Forms.RadioButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.yêuCầuTưVấnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quyĐịnhGiảmGiáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinKhóaHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnHuySua = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaMacDinh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaToiDa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownSoLuongKhoaHocDangKy)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbSuaXoaQuyDinhGiamGia
            // 
            this.lbSuaXoaQuyDinhGiamGia.AutoSize = true;
            this.lbSuaXoaQuyDinhGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSuaXoaQuyDinhGiamGia.Location = new System.Drawing.Point(205, 93);
            this.lbSuaXoaQuyDinhGiamGia.Name = "lbSuaXoaQuyDinhGiamGia";
            this.lbSuaXoaQuyDinhGiamGia.Size = new System.Drawing.Size(411, 37);
            this.lbSuaXoaQuyDinhGiamGia.TabIndex = 3;
            this.lbSuaXoaQuyDinhGiamGia.Text = "Chi tiết Quy định giảm giá";
            // 
            // btnSuaQuyDinhGiamGia
            // 
            this.btnSuaQuyDinhGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaQuyDinhGiamGia.Location = new System.Drawing.Point(1533, 788);
            this.btnSuaQuyDinhGiamGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSuaQuyDinhGiamGia.Name = "btnSuaQuyDinhGiamGia";
            this.btnSuaQuyDinhGiamGia.Size = new System.Drawing.Size(244, 70);
            this.btnSuaQuyDinhGiamGia.TabIndex = 25;
            this.btnSuaQuyDinhGiamGia.Text = "Lưu thay đổi";
            this.btnSuaQuyDinhGiamGia.UseVisualStyleBackColor = true;
            this.btnSuaQuyDinhGiamGia.Click += new System.EventHandler(this.btnSuaQuyDinhGiamGia_Click);
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTrangThai.FormattingEnabled = true;
            this.cboTrangThai.Location = new System.Drawing.Point(621, 259);
            this.cboTrangThai.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cboTrangThai.Size = new System.Drawing.Size(462, 40);
            this.cboTrangThai.TabIndex = 26;
            // 
            // lbTrangThai
            // 
            this.lbTrangThai.AutoSize = true;
            this.lbTrangThai.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTrangThai.Location = new System.Drawing.Point(615, 216);
            this.lbTrangThai.Name = "lbTrangThai";
            this.lbTrangThai.Size = new System.Drawing.Size(142, 32);
            this.lbTrangThai.TabIndex = 27;
            this.lbTrangThai.Text = "Trạng thái";
            // 
            // dateTimePickerNgayBatDau
            // 
            this.dateTimePickerNgayBatDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerNgayBatDau.Location = new System.Drawing.Point(127, 598);
            this.dateTimePickerNgayBatDau.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePickerNgayBatDau.Name = "dateTimePickerNgayBatDau";
            this.dateTimePickerNgayBatDau.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateTimePickerNgayBatDau.Size = new System.Drawing.Size(956, 39);
            this.dateTimePickerNgayBatDau.TabIndex = 28;
            // 
            // lbPhanTramGiamGiaMacDinh
            // 
            this.lbPhanTramGiamGiaMacDinh.AutoSize = true;
            this.lbPhanTramGiamGiaMacDinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPhanTramGiamGiaMacDinh.Location = new System.Drawing.Point(119, 764);
            this.lbPhanTramGiamGiaMacDinh.Name = "lbPhanTramGiamGiaMacDinh";
            this.lbPhanTramGiamGiaMacDinh.Size = new System.Drawing.Size(381, 32);
            this.lbPhanTramGiamGiaMacDinh.TabIndex = 29;
            this.lbPhanTramGiamGiaMacDinh.Text = "Phần trăm giảm giá mặc định";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(317, 552);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 36);
            this.label3.TabIndex = 52;
            this.label3.Text = "*";
            // 
            // lbNgayBatDau
            // 
            this.lbNgayBatDau.AutoSize = true;
            this.lbNgayBatDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayBatDau.Location = new System.Drawing.Point(128, 556);
            this.lbNgayBatDau.Name = "lbNgayBatDau";
            this.lbNgayBatDau.Size = new System.Drawing.Size(182, 32);
            this.lbNgayBatDau.TabIndex = 53;
            this.lbNgayBatDau.Text = "Ngày bắt đầu";
            // 
            // dateTimePickerNgayKetThuc
            // 
            this.dateTimePickerNgayKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerNgayKetThuc.Location = new System.Drawing.Point(1142, 598);
            this.dateTimePickerNgayKetThuc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePickerNgayKetThuc.Name = "dateTimePickerNgayKetThuc";
            this.dateTimePickerNgayKetThuc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateTimePickerNgayKetThuc.Size = new System.Drawing.Size(956, 39);
            this.dateTimePickerNgayKetThuc.TabIndex = 54;
            // 
            // lbNgayKetThuc
            // 
            this.lbNgayKetThuc.AutoSize = true;
            this.lbNgayKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayKetThuc.Location = new System.Drawing.Point(1135, 555);
            this.lbNgayKetThuc.Name = "lbNgayKetThuc";
            this.lbNgayKetThuc.Size = new System.Drawing.Size(186, 32);
            this.lbNgayKetThuc.TabIndex = 55;
            this.lbNgayKetThuc.Text = "Ngày kết thúc";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(1328, 553);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 36);
            this.label1.TabIndex = 56;
            this.label1.Text = "*";
            // 
            // numUpDownPhanTramGiamGiaMacDinh
            // 
            this.numUpDownPhanTramGiamGiaMacDinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownPhanTramGiamGiaMacDinh.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaMacDinh.Location = new System.Drawing.Point(125, 807);
            this.numUpDownPhanTramGiamGiaMacDinh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numUpDownPhanTramGiamGiaMacDinh.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaMacDinh.Name = "numUpDownPhanTramGiamGiaMacDinh";
            this.numUpDownPhanTramGiamGiaMacDinh.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numUpDownPhanTramGiamGiaMacDinh.Size = new System.Drawing.Size(453, 39);
            this.numUpDownPhanTramGiamGiaMacDinh.TabIndex = 57;
            // 
            // numUpDownPhanTramGiamGiaToiDa
            // 
            this.numUpDownPhanTramGiamGiaToiDa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownPhanTramGiamGiaToiDa.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaToiDa.Location = new System.Drawing.Point(618, 806);
            this.numUpDownPhanTramGiamGiaToiDa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numUpDownPhanTramGiamGiaToiDa.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaToiDa.Name = "numUpDownPhanTramGiamGiaToiDa";
            this.numUpDownPhanTramGiamGiaToiDa.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numUpDownPhanTramGiamGiaToiDa.Size = new System.Drawing.Size(461, 39);
            this.numUpDownPhanTramGiamGiaToiDa.TabIndex = 58;
            this.numUpDownPhanTramGiamGiaToiDa.ValueChanged += new System.EventHandler(this.numUpDownPhanTramGiamGiaToiDa_ValueChanged);
            // 
            // lbPhanTramGiamGiaToiDa
            // 
            this.lbPhanTramGiamGiaToiDa.AutoSize = true;
            this.lbPhanTramGiamGiaToiDa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPhanTramGiamGiaToiDa.Location = new System.Drawing.Point(611, 763);
            this.lbPhanTramGiamGiaToiDa.Name = "lbPhanTramGiamGiaToiDa";
            this.lbPhanTramGiamGiaToiDa.Size = new System.Drawing.Size(336, 32);
            this.lbPhanTramGiamGiaToiDa.TabIndex = 59;
            this.lbPhanTramGiamGiaToiDa.Text = "Phần trăm giảm giá tối đa";
            this.lbPhanTramGiamGiaToiDa.Click += new System.EventHandler(this.lbPhanTramGiamGiaToiDa_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(507, 760);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 36);
            this.label2.TabIndex = 60;
            this.label2.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(849, 362);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 36);
            this.label4.TabIndex = 61;
            this.label4.Text = "*";
            // 
            // numUpDownSoLuongKhoaHocDangKy
            // 
            this.numUpDownSoLuongKhoaHocDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownSoLuongKhoaHocDangKy.Location = new System.Drawing.Point(127, 414);
            this.numUpDownSoLuongKhoaHocDangKy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numUpDownSoLuongKhoaHocDangKy.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownSoLuongKhoaHocDangKy.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDownSoLuongKhoaHocDangKy.Name = "numUpDownSoLuongKhoaHocDangKy";
            this.numUpDownSoLuongKhoaHocDangKy.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numUpDownSoLuongKhoaHocDangKy.Size = new System.Drawing.Size(455, 39);
            this.numUpDownSoLuongKhoaHocDangKy.TabIndex = 62;
            this.numUpDownSoLuongKhoaHocDangKy.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lbSoLuongKhoaHocDangKy
            // 
            this.lbSoLuongKhoaHocDangKy.AutoSize = true;
            this.lbSoLuongKhoaHocDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoLuongKhoaHocDangKy.Location = new System.Drawing.Point(121, 370);
            this.lbSoLuongKhoaHocDangKy.Name = "lbSoLuongKhoaHocDangKy";
            this.lbSoLuongKhoaHocDangKy.Size = new System.Drawing.Size(355, 32);
            this.lbSoLuongKhoaHocDangKy.TabIndex = 63;
            this.lbSoLuongKhoaHocDangKy.Text = "Số lượng khóa học đăng ký";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(493, 363);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 36);
            this.label5.TabIndex = 64;
            this.label5.Text = "*";
            // 
            // cboNgheNghiep
            // 
            this.cboNgheNghiep.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNgheNghiep.FormattingEnabled = true;
            this.cboNgheNghiep.Location = new System.Drawing.Point(621, 414);
            this.cboNgheNghiep.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboNgheNghiep.Name = "cboNgheNghiep";
            this.cboNgheNghiep.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cboNgheNghiep.Size = new System.Drawing.Size(462, 40);
            this.cboNgheNghiep.TabIndex = 65;
            // 
            // lbTenNgheNghiep
            // 
            this.lbTenNgheNghiep.AutoSize = true;
            this.lbTenNgheNghiep.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenNgheNghiep.Location = new System.Drawing.Point(614, 366);
            this.lbTenNgheNghiep.Name = "lbTenNgheNghiep";
            this.lbTenNgheNghiep.Size = new System.Drawing.Size(228, 32);
            this.lbTenNgheNghiep.TabIndex = 66;
            this.lbTenNgheNghiep.Text = "Tên nghề nghiệp";
            // 
            // txtMoTaLoaiGiamGia
            // 
            this.txtMoTaLoaiGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMoTaLoaiGiamGia.Location = new System.Drawing.Point(1141, 260);
            this.txtMoTaLoaiGiamGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMoTaLoaiGiamGia.Name = "txtMoTaLoaiGiamGia";
            this.txtMoTaLoaiGiamGia.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMoTaLoaiGiamGia.Size = new System.Drawing.Size(957, 39);
            this.txtMoTaLoaiGiamGia.TabIndex = 67;
            // 
            // lbMoTaLoaiGiamGia
            // 
            this.lbMoTaLoaiGiamGia.AutoSize = true;
            this.lbMoTaLoaiGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMoTaLoaiGiamGia.Location = new System.Drawing.Point(1134, 217);
            this.lbMoTaLoaiGiamGia.Name = "lbMoTaLoaiGiamGia";
            this.lbMoTaLoaiGiamGia.Size = new System.Drawing.Size(314, 32);
            this.lbMoTaLoaiGiamGia.TabIndex = 68;
            this.lbMoTaLoaiGiamGia.Text = "Mô tả quy định giảm giá";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(972, 763);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 36);
            this.label6.TabIndex = 69;
            this.label6.Text = "*";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(1455, 214);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 36);
            this.label7.TabIndex = 70;
            this.label7.Text = "*";
            // 
            // txtMaQuyDinhGiamGia
            // 
            this.txtMaQuyDinhGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaQuyDinhGiamGia.Location = new System.Drawing.Point(127, 260);
            this.txtMaQuyDinhGiamGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaQuyDinhGiamGia.Name = "txtMaQuyDinhGiamGia";
            this.txtMaQuyDinhGiamGia.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMaQuyDinhGiamGia.Size = new System.Drawing.Size(455, 39);
            this.txtMaQuyDinhGiamGia.TabIndex = 71;
            // 
            // lbMaQuyDinhGiamGia
            // 
            this.lbMaQuyDinhGiamGia.AutoSize = true;
            this.lbMaQuyDinhGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaQuyDinhGiamGia.Location = new System.Drawing.Point(121, 217);
            this.lbMaQuyDinhGiamGia.Name = "lbMaQuyDinhGiamGia";
            this.lbMaQuyDinhGiamGia.Size = new System.Drawing.Size(283, 32);
            this.lbMaQuyDinhGiamGia.TabIndex = 72;
            this.lbMaQuyDinhGiamGia.Text = "Mã quy định giảm giá";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(411, 214);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 36);
            this.label8.TabIndex = 73;
            this.label8.Text = "*";
            // 
            // btnSelectedXoa
            // 
            this.btnSelectedXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectedXoa.Location = new System.Drawing.Point(1991, 82);
            this.btnSelectedXoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectedXoa.Name = "btnSelectedXoa";
            this.btnSelectedXoa.Size = new System.Drawing.Size(102, 58);
            this.btnSelectedXoa.TabIndex = 75;
            this.btnSelectedXoa.Text = "🗑️";
            this.btnSelectedXoa.UseVisualStyleBackColor = true;
            this.btnSelectedXoa.Click += new System.EventHandler(this.btnSelectedXoa_Click);
            // 
            // btnSelectedSua
            // 
            this.btnSelectedSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectedSua.Location = new System.Drawing.Point(1848, 82);
            this.btnSelectedSua.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectedSua.Name = "btnSelectedSua";
            this.btnSelectedSua.Size = new System.Drawing.Size(102, 58);
            this.btnSelectedSua.TabIndex = 76;
            this.btnSelectedSua.Text = "✏️";
            this.btnSelectedSua.UseVisualStyleBackColor = true;
            this.btnSelectedSua.Click += new System.EventHandler(this.btnSelectedSua_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnNoDate);
            this.groupBox1.Controls.Add(this.rbtnYesDate);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(1141, 370);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(957, 104);
            this.groupBox1.TabIndex = 78;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thời gian áp dụng";
            // 
            // rbtnNoDate
            // 
            this.rbtnNoDate.AutoSize = true;
            this.rbtnNoDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnNoDate.Location = new System.Drawing.Point(406, 46);
            this.rbtnNoDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnNoDate.Name = "rbtnNoDate";
            this.rbtnNoDate.Size = new System.Drawing.Size(230, 36);
            this.rbtnNoDate.TabIndex = 1;
            this.rbtnNoDate.TabStop = true;
            this.rbtnNoDate.Text = "Không giới hạn";
            this.rbtnNoDate.UseVisualStyleBackColor = true;
            this.rbtnNoDate.CheckedChanged += new System.EventHandler(this.rbtnNoDate_CheckedChanged);
            // 
            // rbtnYesDate
            // 
            this.rbtnYesDate.AutoSize = true;
            this.rbtnYesDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnYesDate.Location = new System.Drawing.Point(21, 46);
            this.rbtnYesDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnYesDate.Name = "rbtnYesDate";
            this.rbtnYesDate.Size = new System.Drawing.Size(146, 36);
            this.rbtnYesDate.TabIndex = 0;
            this.rbtnYesDate.TabStop = true;
            this.rbtnYesDate.Text = "Giới hạn";
            this.rbtnYesDate.UseVisualStyleBackColor = true;
            this.rbtnYesDate.CheckedChanged += new System.EventHandler(this.rbtnYesDate_CheckedChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yêuCầuTưVấnToolStripMenuItem,
            this.leadToolStripMenuItem,
            this.kháchHàngToolStripMenuItem,
            this.quyĐịnhGiảmGiáToolStripMenuItem,
            this.thôngTinKhóaHọcToolStripMenuItem,
            this.báoCáoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(2367, 31);
            this.menuStrip1.TabIndex = 79;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // yêuCầuTưVấnToolStripMenuItem
            // 
            this.yêuCầuTưVấnToolStripMenuItem.Name = "yêuCầuTưVấnToolStripMenuItem";
            this.yêuCầuTưVấnToolStripMenuItem.Size = new System.Drawing.Size(142, 29);
            this.yêuCầuTưVấnToolStripMenuItem.Text = "Yêu cầu tư vấn";
            this.yêuCầuTưVấnToolStripMenuItem.Click += new System.EventHandler(this.yêuCầuTưVấnToolStripMenuItem_Click);
            // 
            // leadToolStripMenuItem
            // 
            this.leadToolStripMenuItem.Name = "leadToolStripMenuItem";
            this.leadToolStripMenuItem.Size = new System.Drawing.Size(65, 29);
            this.leadToolStripMenuItem.Text = "Lead";
            // 
            // kháchHàngToolStripMenuItem
            // 
            this.kháchHàngToolStripMenuItem.Name = "kháchHàngToolStripMenuItem";
            this.kháchHàngToolStripMenuItem.Size = new System.Drawing.Size(120, 29);
            this.kháchHàngToolStripMenuItem.Text = "Khách hàng";
            this.kháchHàngToolStripMenuItem.Click += new System.EventHandler(this.kháchHàngToolStripMenuItem_Click);
            // 
            // quyĐịnhGiảmGiáToolStripMenuItem
            // 
            this.quyĐịnhGiảmGiáToolStripMenuItem.Name = "quyĐịnhGiảmGiáToolStripMenuItem";
            this.quyĐịnhGiảmGiáToolStripMenuItem.Size = new System.Drawing.Size(175, 29);
            this.quyĐịnhGiảmGiáToolStripMenuItem.Text = "Quy định giảm giá";
            this.quyĐịnhGiảmGiáToolStripMenuItem.Click += new System.EventHandler(this.quyĐịnhGiảmGiáToolStripMenuItem_Click);
            // 
            // thôngTinKhóaHọcToolStripMenuItem
            // 
            this.thôngTinKhóaHọcToolStripMenuItem.Name = "thôngTinKhóaHọcToolStripMenuItem";
            this.thôngTinKhóaHọcToolStripMenuItem.Size = new System.Drawing.Size(182, 29);
            this.thôngTinKhóaHọcToolStripMenuItem.Text = "Thông tin khóa học";
            this.thôngTinKhóaHọcToolStripMenuItem.Click += new System.EventHandler(this.thôngTinKhóaHọcToolStripMenuItem_Click);
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(91, 29);
            this.báoCáoToolStripMenuItem.Text = "Báo cáo";
            // 
            // btnHuySua
            // 
            this.btnHuySua.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuySua.Location = new System.Drawing.Point(1849, 788);
            this.btnHuySua.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnHuySua.Name = "btnHuySua";
            this.btnHuySua.Size = new System.Drawing.Size(244, 70);
            this.btnHuySua.TabIndex = 80;
            this.btnHuySua.Text = "Hủy chỉnh sửa";
            this.btnHuySua.UseVisualStyleBackColor = true;
            this.btnHuySua.Click += new System.EventHandler(this.btnHuySua_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(120, 86);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(61, 51);
            this.btnBack.TabIndex = 91;
            this.btnBack.Text = "<";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmChiTietQuyDinhGiamGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2367, 1319);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnHuySua);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSelectedSua);
            this.Controls.Add(this.btnSelectedXoa);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbMaQuyDinhGiamGia);
            this.Controls.Add(this.txtMaQuyDinhGiamGia);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbMoTaLoaiGiamGia);
            this.Controls.Add(this.txtMoTaLoaiGiamGia);
            this.Controls.Add(this.lbTenNgheNghiep);
            this.Controls.Add(this.cboNgheNghiep);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbSoLuongKhoaHocDangKy);
            this.Controls.Add(this.numUpDownSoLuongKhoaHocDangKy);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbPhanTramGiamGiaToiDa);
            this.Controls.Add(this.numUpDownPhanTramGiamGiaToiDa);
            this.Controls.Add(this.numUpDownPhanTramGiamGiaMacDinh);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbNgayKetThuc);
            this.Controls.Add(this.dateTimePickerNgayKetThuc);
            this.Controls.Add(this.lbNgayBatDau);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbPhanTramGiamGiaMacDinh);
            this.Controls.Add(this.dateTimePickerNgayBatDau);
            this.Controls.Add(this.lbTrangThai);
            this.Controls.Add(this.cboTrangThai);
            this.Controls.Add(this.btnSuaQuyDinhGiamGia);
            this.Controls.Add(this.lbSuaXoaQuyDinhGiamGia);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmChiTietQuyDinhGiamGia";
            this.Text = "Danh sách Quy định giảm giá";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSuaXoaQuyDinhGiamGia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaMacDinh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaToiDa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownSoLuongKhoaHocDangKy)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbSuaXoaQuyDinhGiamGia;
        private System.Windows.Forms.Button btnSuaQuyDinhGiamGia;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.Label lbTrangThai;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayBatDau;
        private System.Windows.Forms.Label lbPhanTramGiamGiaMacDinh;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbNgayBatDau;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayKetThuc;
        private System.Windows.Forms.Label lbNgayKetThuc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numUpDownPhanTramGiamGiaMacDinh;
        private System.Windows.Forms.NumericUpDown numUpDownPhanTramGiamGiaToiDa;
        private System.Windows.Forms.Label lbPhanTramGiamGiaToiDa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numUpDownSoLuongKhoaHocDangKy;
        private System.Windows.Forms.Label lbSoLuongKhoaHocDangKy;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboNgheNghiep;
        private System.Windows.Forms.Label lbTenNgheNghiep;
        private System.Windows.Forms.TextBox txtMoTaLoaiGiamGia;
        private System.Windows.Forms.Label lbMoTaLoaiGiamGia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMaQuyDinhGiamGia;
        private System.Windows.Forms.Label lbMaQuyDinhGiamGia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSelectedXoa;
        private System.Windows.Forms.Button btnSelectedSua;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnNoDate;
        private System.Windows.Forms.RadioButton rbtnYesDate;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem yêuCầuTưVấnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quyĐịnhGiảmGiáToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinKhóaHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.Button btnHuySua;
        private System.Windows.Forms.Button btnBack;
    }
}