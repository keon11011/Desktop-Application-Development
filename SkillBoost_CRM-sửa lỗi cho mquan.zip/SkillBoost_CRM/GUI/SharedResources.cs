﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI
{
    public static class SharedResources
    {
        public static string MaPIC;
        public static string ChucVu;
        public static string TenPIC;
        public static string MaLead;
        public static string MaQuyDinhGiamGia;
    }

}
