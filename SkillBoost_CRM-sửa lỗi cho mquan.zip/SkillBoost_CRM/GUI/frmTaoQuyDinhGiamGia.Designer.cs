﻿namespace GUI
{
    partial class frmTaoQuyDinhGiamGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.lbTaoQuyDinhGiamGia = new System.Windows.Forms.Label();
            this.lbMoTaLoaiGiamGia = new System.Windows.Forms.Label();
            this.txtMoTaLoaiGiamGia = new System.Windows.Forms.TextBox();
            this.lbSoLuongKhoaHocDangKy = new System.Windows.Forms.Label();
            this.lbTenNgheNghiep = new System.Windows.Forms.Label();
            this.lbPhanTramGiamGiaMacDinh = new System.Windows.Forms.Label();
            this.lbPhanTramGiamGiaToiDa = new System.Windows.Forms.Label();
            this.lbNgayBatDau = new System.Windows.Forms.Label();
            this.lbNgayKetThuc = new System.Windows.Forms.Label();
            this.dateTimePickerNgayBatDau = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerNgayKetThuc = new System.Windows.Forms.DateTimePicker();
            this.btnTaoQuyDinhGiamGIa = new System.Windows.Forms.Button();
            this.cboNgheNghiep = new System.Windows.Forms.ComboBox();
            this.numUpDownSoLuongKhoaHocDangKy = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPhanTramGiamGiaMacDinh = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPhanTramGiamGiaToiDa = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnNoDate = new System.Windows.Forms.RadioButton();
            this.rbtnYesDate = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownSoLuongKhoaHocDangKy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaMacDinh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaToiDa)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(13, 13);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(57, 50);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "<";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lbTaoQuyDinhGiamGia
            // 
            this.lbTaoQuyDinhGiamGia.AutoSize = true;
            this.lbTaoQuyDinhGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTaoQuyDinhGiamGia.Location = new System.Drawing.Point(105, 19);
            this.lbTaoQuyDinhGiamGia.Name = "lbTaoQuyDinhGiamGia";
            this.lbTaoQuyDinhGiamGia.Size = new System.Drawing.Size(357, 38);
            this.lbTaoQuyDinhGiamGia.TabIndex = 2;
            this.lbTaoQuyDinhGiamGia.Text = "Tạo quy định giảm giá";
            // 
            // lbMoTaLoaiGiamGia
            // 
            this.lbMoTaLoaiGiamGia.AutoSize = true;
            this.lbMoTaLoaiGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMoTaLoaiGiamGia.Location = new System.Drawing.Point(104, 110);
            this.lbMoTaLoaiGiamGia.Name = "lbMoTaLoaiGiamGia";
            this.lbMoTaLoaiGiamGia.Size = new System.Drawing.Size(314, 32);
            this.lbMoTaLoaiGiamGia.TabIndex = 5;
            this.lbMoTaLoaiGiamGia.Text = "Mô tả quy định giảm giá";
            // 
            // txtMoTaLoaiGiamGia
            // 
            this.txtMoTaLoaiGiamGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMoTaLoaiGiamGia.Location = new System.Drawing.Point(110, 166);
            this.txtMoTaLoaiGiamGia.Name = "txtMoTaLoaiGiamGia";
            this.txtMoTaLoaiGiamGia.Size = new System.Drawing.Size(1734, 38);
            this.txtMoTaLoaiGiamGia.TabIndex = 6;
            // 
            // lbSoLuongKhoaHocDangKy
            // 
            this.lbSoLuongKhoaHocDangKy.AutoSize = true;
            this.lbSoLuongKhoaHocDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoLuongKhoaHocDangKy.Location = new System.Drawing.Point(104, 259);
            this.lbSoLuongKhoaHocDangKy.Name = "lbSoLuongKhoaHocDangKy";
            this.lbSoLuongKhoaHocDangKy.Size = new System.Drawing.Size(355, 32);
            this.lbSoLuongKhoaHocDangKy.TabIndex = 7;
            this.lbSoLuongKhoaHocDangKy.Text = "Số lượng khóa học đăng ký";
            // 
            // lbTenNgheNghiep
            // 
            this.lbTenNgheNghiep.AutoSize = true;
            this.lbTenNgheNghiep.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenNgheNghiep.Location = new System.Drawing.Point(989, 259);
            this.lbTenNgheNghiep.Name = "lbTenNgheNghiep";
            this.lbTenNgheNghiep.Size = new System.Drawing.Size(228, 32);
            this.lbTenNgheNghiep.TabIndex = 11;
            this.lbTenNgheNghiep.Text = "Tên nghề nghiệp";
            // 
            // lbPhanTramGiamGiaMacDinh
            // 
            this.lbPhanTramGiamGiaMacDinh.AutoSize = true;
            this.lbPhanTramGiamGiaMacDinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPhanTramGiamGiaMacDinh.Location = new System.Drawing.Point(106, 397);
            this.lbPhanTramGiamGiaMacDinh.Name = "lbPhanTramGiamGiaMacDinh";
            this.lbPhanTramGiamGiaMacDinh.Size = new System.Drawing.Size(381, 32);
            this.lbPhanTramGiamGiaMacDinh.TabIndex = 13;
            this.lbPhanTramGiamGiaMacDinh.Text = "Phần trăm giảm giá mặc định";
            // 
            // lbPhanTramGiamGiaToiDa
            // 
            this.lbPhanTramGiamGiaToiDa.AutoSize = true;
            this.lbPhanTramGiamGiaToiDa.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPhanTramGiamGiaToiDa.Location = new System.Drawing.Point(989, 397);
            this.lbPhanTramGiamGiaToiDa.Name = "lbPhanTramGiamGiaToiDa";
            this.lbPhanTramGiamGiaToiDa.Size = new System.Drawing.Size(336, 32);
            this.lbPhanTramGiamGiaToiDa.TabIndex = 15;
            this.lbPhanTramGiamGiaToiDa.Text = "Phần trăm giảm giá tối đa";
            // 
            // lbNgayBatDau
            // 
            this.lbNgayBatDau.AutoSize = true;
            this.lbNgayBatDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayBatDau.Location = new System.Drawing.Point(109, 638);
            this.lbNgayBatDau.Name = "lbNgayBatDau";
            this.lbNgayBatDau.Size = new System.Drawing.Size(182, 32);
            this.lbNgayBatDau.TabIndex = 17;
            this.lbNgayBatDau.Text = "Ngày bắt đầu";
            // 
            // lbNgayKetThuc
            // 
            this.lbNgayKetThuc.AutoSize = true;
            this.lbNgayKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayKetThuc.Location = new System.Drawing.Point(990, 638);
            this.lbNgayKetThuc.Name = "lbNgayKetThuc";
            this.lbNgayKetThuc.Size = new System.Drawing.Size(186, 32);
            this.lbNgayKetThuc.TabIndex = 19;
            this.lbNgayKetThuc.Text = "Ngày kết thúc";
            // 
            // dateTimePickerNgayBatDau
            // 
            this.dateTimePickerNgayBatDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerNgayBatDau.Location = new System.Drawing.Point(113, 695);
            this.dateTimePickerNgayBatDau.Name = "dateTimePickerNgayBatDau";
            this.dateTimePickerNgayBatDau.Size = new System.Drawing.Size(823, 38);
            this.dateTimePickerNgayBatDau.TabIndex = 21;
            // 
            // dateTimePickerNgayKetThuc
            // 
            this.dateTimePickerNgayKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerNgayKetThuc.Location = new System.Drawing.Point(995, 695);
            this.dateTimePickerNgayKetThuc.Name = "dateTimePickerNgayKetThuc";
            this.dateTimePickerNgayKetThuc.Size = new System.Drawing.Size(850, 38);
            this.dateTimePickerNgayKetThuc.TabIndex = 22;
            // 
            // btnTaoQuyDinhGiamGIa
            // 
            this.btnTaoQuyDinhGiamGIa.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaoQuyDinhGiamGIa.Location = new System.Drawing.Point(1729, 790);
            this.btnTaoQuyDinhGiamGIa.Name = "btnTaoQuyDinhGiamGIa";
            this.btnTaoQuyDinhGiamGIa.Size = new System.Drawing.Size(116, 56);
            this.btnTaoQuyDinhGiamGIa.TabIndex = 23;
            this.btnTaoQuyDinhGiamGIa.Text = "Tạo";
            this.btnTaoQuyDinhGiamGIa.UseVisualStyleBackColor = true;
            this.btnTaoQuyDinhGiamGIa.Click += new System.EventHandler(this.btnTaoQuyDinhGiamGIa_Click);
            // 
            // cboNgheNghiep
            // 
            this.cboNgheNghiep.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNgheNghiep.FormattingEnabled = true;
            this.cboNgheNghiep.Location = new System.Drawing.Point(994, 311);
            this.cboNgheNghiep.Name = "cboNgheNghiep";
            this.cboNgheNghiep.Size = new System.Drawing.Size(850, 39);
            this.cboNgheNghiep.TabIndex = 24;
            // 
            // numUpDownSoLuongKhoaHocDangKy
            // 
            this.numUpDownSoLuongKhoaHocDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownSoLuongKhoaHocDangKy.Location = new System.Drawing.Point(110, 312);
            this.numUpDownSoLuongKhoaHocDangKy.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownSoLuongKhoaHocDangKy.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDownSoLuongKhoaHocDangKy.Name = "numUpDownSoLuongKhoaHocDangKy";
            this.numUpDownSoLuongKhoaHocDangKy.Size = new System.Drawing.Size(825, 38);
            this.numUpDownSoLuongKhoaHocDangKy.TabIndex = 25;
            this.numUpDownSoLuongKhoaHocDangKy.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numUpDownPhanTramGiamGiaMacDinh
            // 
            this.numUpDownPhanTramGiamGiaMacDinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownPhanTramGiamGiaMacDinh.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaMacDinh.Location = new System.Drawing.Point(112, 449);
            this.numUpDownPhanTramGiamGiaMacDinh.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaMacDinh.Name = "numUpDownPhanTramGiamGiaMacDinh";
            this.numUpDownPhanTramGiamGiaMacDinh.Size = new System.Drawing.Size(823, 38);
            this.numUpDownPhanTramGiamGiaMacDinh.TabIndex = 26;
            // 
            // numUpDownPhanTramGiamGiaToiDa
            // 
            this.numUpDownPhanTramGiamGiaToiDa.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownPhanTramGiamGiaToiDa.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaToiDa.Location = new System.Drawing.Point(994, 449);
            this.numUpDownPhanTramGiamGiaToiDa.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numUpDownPhanTramGiamGiaToiDa.Name = "numUpDownPhanTramGiamGiaToiDa";
            this.numUpDownPhanTramGiamGiaToiDa.Size = new System.Drawing.Size(850, 38);
            this.numUpDownPhanTramGiamGiaToiDa.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(425, 110);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 29);
            this.label1.TabIndex = 49;
            this.label1.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(466, 259);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 29);
            this.label2.TabIndex = 50;
            this.label2.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(494, 399);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 29);
            this.label3.TabIndex = 51;
            this.label3.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(1332, 397);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 29);
            this.label4.TabIndex = 52;
            this.label4.Text = "*";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnNoDate);
            this.groupBox1.Controls.Add(this.rbtnYesDate);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(110, 519);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(826, 104);
            this.groupBox1.TabIndex = 53;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thời gian áp dụng";
            // 
            // rbtnNoDate
            // 
            this.rbtnNoDate.AutoSize = true;
            this.rbtnNoDate.Location = new System.Drawing.Point(361, 37);
            this.rbtnNoDate.Name = "rbtnNoDate";
            this.rbtnNoDate.Size = new System.Drawing.Size(226, 36);
            this.rbtnNoDate.TabIndex = 1;
            this.rbtnNoDate.TabStop = true;
            this.rbtnNoDate.Text = "Không giới hạn";
            this.rbtnNoDate.UseVisualStyleBackColor = true;
            this.rbtnNoDate.CheckedChanged += new System.EventHandler(this.rbtnNoDate_CheckedChanged);
            // 
            // rbtnYesDate
            // 
            this.rbtnYesDate.AutoSize = true;
            this.rbtnYesDate.Location = new System.Drawing.Point(19, 37);
            this.rbtnYesDate.Name = "rbtnYesDate";
            this.rbtnYesDate.Size = new System.Drawing.Size(142, 36);
            this.rbtnYesDate.TabIndex = 0;
            this.rbtnYesDate.TabStop = true;
            this.rbtnYesDate.Text = "Giới hạn";
            this.rbtnYesDate.UseVisualStyleBackColor = true;
            this.rbtnYesDate.CheckedChanged += new System.EventHandler(this.rbtnYesDate_CheckedChanged);
            // 
            // frmTaoQuyDinhGiamGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numUpDownPhanTramGiamGiaToiDa);
            this.Controls.Add(this.numUpDownPhanTramGiamGiaMacDinh);
            this.Controls.Add(this.numUpDownSoLuongKhoaHocDangKy);
            this.Controls.Add(this.cboNgheNghiep);
            this.Controls.Add(this.btnTaoQuyDinhGiamGIa);
            this.Controls.Add(this.dateTimePickerNgayKetThuc);
            this.Controls.Add(this.dateTimePickerNgayBatDau);
            this.Controls.Add(this.lbNgayKetThuc);
            this.Controls.Add(this.lbNgayBatDau);
            this.Controls.Add(this.lbPhanTramGiamGiaToiDa);
            this.Controls.Add(this.lbPhanTramGiamGiaMacDinh);
            this.Controls.Add(this.lbTenNgheNghiep);
            this.Controls.Add(this.lbSoLuongKhoaHocDangKy);
            this.Controls.Add(this.txtMoTaLoaiGiamGia);
            this.Controls.Add(this.lbMoTaLoaiGiamGia);
            this.Controls.Add(this.lbTaoQuyDinhGiamGia);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label3);
            this.Name = "frmTaoQuyDinhGiamGia";
            this.Text = "frmTaoQuyDinhGiamGia";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmTaoQuyDinhGiamGia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownSoLuongKhoaHocDangKy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaMacDinh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPhanTramGiamGiaToiDa)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lbTaoQuyDinhGiamGia;
        private System.Windows.Forms.Label lbMoTaLoaiGiamGia;
        private System.Windows.Forms.TextBox txtMoTaLoaiGiamGia;
        private System.Windows.Forms.Label lbSoLuongKhoaHocDangKy;
        private System.Windows.Forms.Label lbTenNgheNghiep;
        private System.Windows.Forms.Label lbPhanTramGiamGiaMacDinh;
        private System.Windows.Forms.Label lbPhanTramGiamGiaToiDa;
        private System.Windows.Forms.Label lbNgayBatDau;
        private System.Windows.Forms.Label lbNgayKetThuc;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayBatDau;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayKetThuc;
        private System.Windows.Forms.Button btnTaoQuyDinhGiamGIa;
        private System.Windows.Forms.ComboBox cboNgheNghiep;
        private System.Windows.Forms.NumericUpDown numUpDownSoLuongKhoaHocDangKy;
        private System.Windows.Forms.NumericUpDown numUpDownPhanTramGiamGiaMacDinh;
        private System.Windows.Forms.NumericUpDown numUpDownPhanTramGiamGiaToiDa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnYesDate;
        private System.Windows.Forms.RadioButton rbtnNoDate;
    }
}